<?php

declare(strict_types=1);
/**
 * Copyright 2022-2025 FOSSBilling.
 * SPDX-License-Identifier: Apache-2.0.
 *
 * @copyright FOSSBilling (https://www.fossbilling.org)
 * @license http://www.apache.org/licenses/LICENSE-2.0 Apache-2.0
 */

namespace FOSSBilling\Twig\Extension;

use DebugBar\JavascriptRenderer;
use DebugBar\StandardDebugBar;
use FOSSBilling\Environment;
use Twig\Attribute\AsTwigFunction;

class DebugBarExtension
{
    private readonly JavascriptRenderer $debugbarRenderer;

    public function __construct(StandardDebugBar $debugBar)
    {
        $this->debugbarRenderer = $debugBar->getJavascriptRenderer();
    }

    #[AsTwigFunction('debug_bar_render_head', isSafe: ['html'])]
    public function renderHead(): string
    {
        if (!Environment::isDevelopment()) {
            return '';
        }

        $css = $this->debugbarRenderer->dumpCssAssets(echo: false);
        $js = $this->debugbarRenderer->dumpJsAssets(echo: false);
        $head = $this->debugbarRenderer->dumpHeadAssets(echo: false);

        $html = '';
        if ($css) {
            $html .= '<style>' . $css . '</style>';
        }
        if ($js) {
            $html .= '<script type="text/javascript">' . $js . '</script>';
        }

        return $html . $head;
    }

    #[AsTwigFunction('debug_bar_render', isSafe: ['html'])]
    public function render(): string
    {
        return (Environment::isDevelopment()) ? $this->debugbarRenderer->render() : '';
    }
}
