<?php

declare(strict_types=1);
/**
 * Copyright 2022-2025 FOSSBilling
 * Copyright 2011-2021 BoxBilling, Inc.
 * SPDX-License-Identifier: Apache-2.0.
 *
 * @copyright FOSSBilling (https://www.fossbilling.org)
 * @license http://www.apache.org/licenses/LICENSE-2.0 Apache-2.0
 */
class Box_DbLoggedPDOStatement extends PDOStatement
{
    public function execute(?array $input_parameters = null): bool
    {
        error_log($this->queryString);

        return parent::execute($input_parameters);
    }
}
