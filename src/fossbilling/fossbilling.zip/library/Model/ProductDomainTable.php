<?php

declare(strict_types=1);
/**
 * Copyright 2022-2025 FOSSBilling
 * Copyright 2011-2021 BoxBilling, Inc.
 * SPDX-License-Identifier: Apache-2.0.
 *
 * @copyright FOSSBilling (https://www.fossbilling.org)
 * @license http://www.apache.org/licenses/LICENSE-2.0 Apache-2.0
 */
class Model_ProductDomainTable extends Model_ProductTable
{
    #[Override]
    public function getUnit(Model_Product $model): string
    {
        return 'year';
    }

    private function getRegistrationYears(array $config): int
    {
        if (isset($config['period']) && is_string($config['period']) && $config['period'] !== '') {
            $period = $this->di['period']($config['period']);

            return max(1, $period->getQty());
        }

        return max(1, (int) ($config['register_years'] ?? $config['quantity'] ?? 1));
    }

    private function getTldModel(array $config): Model_Tld
    {
        $rtable = $this->di['mod_service']('servicedomain', 'Tld');
        $tld = '';

        if (!isset($config['action'])) {
            throw new FOSSBilling\Exception('Could not determine domain price. Domain action is missing', null, 498);
        }

        if ($config['action'] == 'register') {
            $tld = $config['register_tld'];
        }

        if ($config['action'] == 'transfer') {
            $tld = $config['transfer_tld'];
        }

        $tld = $rtable->findOneByTld($tld);
        if (!$tld instanceof Model_Tld) {
            throw new FOSSBilling\Exception('Unknown TLD. Could not determine registration price');
        }

        return $tld;
    }

    private function getRegistrationTotal(Model_Tld $tld, int $years): float
    {
        if ($years <= 0) {
            return 0.0;
        }

        if ($years <= 1) {
            return (float) $tld->price_registration;
        }

        return (float) $tld->price_registration + (($years - 1) * (float) $tld->price_renew);
    }

    protected function getStartingFromPrice(Model_Product $model)
    {
        $p = [];
        $prices = $this->getPricingArray($model);
        foreach ($prices as $tld) {
            $p[] = $tld['price_registration'];
        }

        return empty($p) ? 0 : min($p);
    }

    public function isRecurrentPricing(Model_Product $model): bool
    {
        return false;
    }

    /**
     * Determine discount for items in cart (Hosting and related domain discount).
     *
     * @param array         $items   Array of cart products
     * @param Model_Product $product current product in iteration
     * @param array         $config  configurations specified in product config
     *
     * @return number discount
     */
    public function getRelatedDiscount(array $items, Model_Product $product, array $config)
    {
        /**For each cart product,
         * Compare it with other items in the cart
         * If a domain has related hosting package, determine discount configured.
         */
        foreach ($items as $addon) {
            if (
                $this->isActionNameSet($addon, 'register')
                && $this->_isFreeDomainSet($addon)
                && $this->registerDomainMatch($addon, $config)
            ) {
                if ($this->_hasFreePeriod($addon)) {
                    $factor = $this->discountFactor($addon, $config['period']);
                    $tld = $this->getTldModel($config);

                    return $this->getRegistrationTotal($tld, $factor);
                }

                return 0;
            }

            if (
                $this->isActionNameSet($addon, 'transfer')
                && $this->isFreeTransferSet($addon)
                && $this->transferDomainMatch($addon, $config)
            ) {
                return $this->getProductPrice($product, $config);
            }
        }

        return 0;
    }

    private function _hasFreePeriod($addon): bool
    {
        $free_domain_periods = $addon['config']['free_domain_periods'] ?? [];
        $addon_period = $addon['config']['period'];
        if (in_array($addon_period, $free_domain_periods)) {
            return true;
        }

        return false;
    }

    /**
     * Determine the number of years configured for free domain.
     */
    private function discountFactor($addon, $period)
    {
        $ref_item_period = $this->di['period']($period);
        $ref_item_qty = $ref_item_period->getQty();

        $addon_period = $addon['config']['period'];
        $addon_sys_period = $this->di['period']($addon_period);
        $addon_qty = $addon_sys_period->getQty();

        $free_domain_periods = $addon['config']['free_domain_periods'] ?? [];
        if (FOSSBilling\Tools::safeCount($free_domain_periods) > 0) {
            // if hosting and domain periods are equal, return domain quantity (year)
            if ($addon_period == $period) {
                if (in_array($addon_period, $free_domain_periods)) {
                    return $ref_item_qty;
                }
            }

            if (str_contains((string) $addon_period, 'Y')) {
                if (min($ref_item_qty, $addon_qty) == 1) {
                    return 1;
                }

                $free_domain_qtys = [];
                foreach ($free_domain_periods as $fp) {
                    $prd = $this->di['period']($fp);
                    $qnty = $prd->getQty();
                    if ($ref_item_qty - $qnty > 0) {
                        $free_domain_qtys[] = $qnty;
                    }
                }

                if (count($free_domain_qtys) > 0) {
                    return min($ref_item_qty, min($free_domain_qtys));
                }
            }
        }

        return 0;
    }

    /**
     * @param string $actionName
     */
    private function isActionNameSet($item, $actionName): bool
    {
        return isset($item['config']['domain']['action']) && $item['config']['domain']['action'] == $actionName;
    }

    private function _isFreeDomainSet($item): bool
    {
        $free_domain = $item['config']['free_domain'] ?? false;

        if (!$free_domain) {
            return false;
        }

        $tld = $item['config']['tld'] ?? null;
        $free_tlds = $item['config']['free_tlds'] ?? [];

        // When free_tlds is empty, all TLDs are eligible for a free domain.
        if (empty($free_tlds)) {
            return true;
        }

        // When free_tlds is non-empty, only whitelisted TLDs are eligible.
        return $tld !== null && in_array($tld, $free_tlds);
    }

    private function registerDomainMatch($item, $config)
    {
        if (!isset($item['config']['domain']['register_sld'])) {
            return false;
        }

        return $item['config']['domain']['register_sld'] == $config['register_sld'] && $item['config']['domain']['register_tld'] == $config['register_tld'];
    }

    private function transferDomainMatch($item, $config)
    {
        if (!isset($item['config']['domain']['transfer_sld'])) {
            return false;
        }

        return $item['config']['domain']['transfer_sld'] == $config['transfer_sld'] && $item['config']['domain']['transfer_tld'] == $config['transfer_tld'];
    }

    private function isFreeTransferSet($item): bool
    {
        return isset($item['config']['free_transfer']) && $item['config']['free_transfer'];
    }

    /**
     * @return array<mixed, array<'active'|'allow_register'|'allow_transfer'|'min_years'|'price_registration'|'price_renew'|'price_transfer'|'registrar'|'tld', mixed>>
     */
    #[Override]
    public function getPricingArray(Model_Product $product): array
    {
        $pricing = [];

        $query = $this->di['dbal']->createQueryBuilder();
        $query
            ->select('t.*', 'r.name')
            ->from('tld', 't')
            ->leftJoin('t', 'tld_registrar', 'r', 'r.id = t.tld_registrar_id')
            ->where('t.active = 1')
            ->orderBy('t.id', 'ASC');

        $result = $query->executeQuery();
        $results = $result->fetchAllAssociative();
        foreach ($results as $tld) {
            $pricing[$tld['tld']] = [
                'tld' => $tld['tld'],
                'price_registration' => $tld['price_registration'],
                'price_renew' => $tld['price_renew'],
                'price_transfer' => $tld['price_transfer'],
                'active' => $tld['active'],
                'allow_register' => $tld['allow_register'],
                'allow_transfer' => $tld['allow_transfer'],
                'min_years' => $tld['min_years'],
                'registrar' => [
                    'id' => $tld['tld_registrar_id'],
                    'title' => $tld['name'],
                ],
            ];
        }

        return $pricing;
    }

    /**
     * @return array{price: float, quantity: int, setup_price: float}
     */
    #[Override]
    public function getOrderLineConfig(Model_Product $product, ?array $config = null): array
    {
        if (!isset($config['action'])) {
            throw new FOSSBilling\Exception('Could not determine domain price. Domain action is missing', null, 498);
        }

        if ($config['action'] == 'owndomain') {
            return [
                'price' => 0.0,
                'quantity' => 1,
                'setup_price' => 0.0,
            ];
        }

        $tld = $this->getTldModel($config);

        if ($config['action'] == 'register') {
            return [
                'price' => $this->getRegistrationTotal($tld, $this->getRegistrationYears($config)),
                'quantity' => 1,
                'setup_price' => 0.0,
            ];
        }

        return [
            'price' => (float) $tld->price_transfer,
            'quantity' => 1,
            'setup_price' => 0.0,
        ];
    }

    /**
     * Resolved pricing for renewal lines in default currency.
     *
     * @return array{price: float, quantity: int}
     */
    public function getRenewalLineConfig(Model_Product $product, ?array $config = null): array
    {
        $tld = $this->getTldModel($config ?? []);

        return [
            'price' => (float) $tld->price_renew,
            'quantity' => $this->getRegistrationYears($config ?? []),
        ];
    }

    #[Override]
    public function getProductPrice(Model_Product $product, ?array $config = null)
    {
        if (($config['action'] ?? null) == 'owndomain') {
            return 0;
        }

        $tld = $this->getTldModel($config ?? []);

        if ($config['action'] == 'register') {
            return $tld->price_registration;
        }

        if ($config['action'] == 'transfer') {
            return $tld->price_transfer;
        }

        return 0;
    }

    #[Override]
    public function getProductSetupPrice(Model_Product $product, ?array $config = null): float
    {
        return (float) 0;
    }

    public function rm(Model_Product $product): never
    {
        throw new FOSSBilling\Exception('Domain product cannot be removed.');
    }
}
