<?php

declare(strict_types=1);
/**
 * Copyright 2022-2025 FOSSBilling
 * Copyright 2011-2021 BoxBilling, Inc.
 * SPDX-License-Identifier: Apache-2.0.
 *
 * @copyright FOSSBilling (https://www.fossbilling.org)
 * @license http://www.apache.org/licenses/LICENSE-2.0 Apache-2.0
 */
class Model_Transaction extends RedBeanPHP\SimpleModel
{
    final public const string STATUS_RECEIVED = 'received';
    final public const string STATUS_APPROVED = 'approved';
    final public const string STATUS_PROCESSING = 'processing';
    final public const string STATUS_PROCESSED = 'processed';
    final public const string STATUS_ERROR = 'error';
}
